/* DC-ShiftMaster Pro — Team management view */
var Team = (function () {
    var SHIFT_TYPES = ['FHD', 'FHN', 'BHD', 'BHN'];

    function renderList(teammates) {
        var container = document.getElementById('team-list');
        container.innerHTML = '';

        var groups = {};
        SHIFT_TYPES.forEach(function (st) { groups[st] = []; });
        teammates.forEach(function (t) {
            if (groups[t.shift_type]) groups[t.shift_type].push(t);
        });

        SHIFT_TYPES.forEach(function (st) {
            var section = document.createElement('div');
            section.className = 'shift-group';
            var title = document.createElement('div');
            title.className = 'shift-group-title';
            title.textContent = st + ' (' + groups[st].length + ')';
            section.appendChild(title);

            groups[st].forEach(function (t) {
                section.appendChild(createRow(t));
            });
            container.appendChild(section);
        });
    }

    function createRow(t) {
        var row = document.createElement('div');
        row.className = 'teammate-row';
        row.setAttribute('data-id', t.id);

        var nameSpan = document.createElement('span');
        nameSpan.className = 'name';
        nameSpan.textContent = t.name;
        row.appendChild(nameSpan);

        if (t.custom_start) {
            var cs = document.createElement('span');
            cs.className = 'custom-start';
            cs.textContent = t.custom_start;
            row.appendChild(cs);
        }

        var actions = document.createElement('span');
        actions.className = 'actions';

        var editBtn = document.createElement('button');
        editBtn.className = 'btn btn-sm';
        editBtn.textContent = 'Edit';
        editBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            showInlineEdit(row, t);
        });

        var delBtn = document.createElement('button');
        delBtn.className = 'btn btn-sm btn-danger';
        delBtn.textContent = 'Del';
        delBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (confirm('Delete teammate "' + t.name + '"?')) {
                API.deleteTeammate(t.id)
                    .then(function () { Toast.show('Deleted ' + t.name, 'success'); load(); })
                    .catch(function (err) { Toast.show(err.message, 'error'); });
            }
        });

        actions.appendChild(editBtn);
        actions.appendChild(delBtn);
        row.appendChild(actions);
        return row;
    }

    function showInlineEdit(row, t) {
        row.innerHTML = '';
        var form = document.createElement('div');
        form.className = 'form-row';
        form.innerHTML =
            '<div class="form-group"><input class="form-control" id="edit-name" value="' + escHtml(t.name) + '"></div>' +
            '<div class="form-group"><select class="form-control" id="edit-shift">' +
            SHIFT_TYPES.map(function (s) { return '<option' + (s === t.shift_type ? ' selected' : '') + '>' + s + '</option>'; }).join('') +
            '</select></div>' +
            '<div class="form-group"><input class="form-control" id="edit-start" placeholder="HH:MM" value="' + escHtml(t.custom_start || '') + '"></div>';
        row.appendChild(form);

        var saveBtn = document.createElement('button');
        saveBtn.className = 'btn btn-primary btn-sm';
        saveBtn.textContent = 'Save';
        saveBtn.addEventListener('click', function () {
            var data = {
                name: document.getElementById('edit-name').value,
                shift_type: document.getElementById('edit-shift').value,
                custom_start: document.getElementById('edit-start').value
            };
            API.updateTeammate(t.id, data)
                .then(function () { Toast.show('Updated', 'success'); load(); })
                .catch(function (err) { Toast.show(err.message, 'error'); });
        });
        var cancelBtn = document.createElement('button');
        cancelBtn.className = 'btn btn-sm';
        cancelBtn.textContent = 'Cancel';
        cancelBtn.addEventListener('click', function () { load(); });
        row.appendChild(saveBtn);
        row.appendChild(cancelBtn);
    }

    function escHtml(s) {
        return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function showAddForm() {
        var container = document.getElementById('add-teammate-form');
        container.hidden = false;
        container.innerHTML =
            '<div class="form-row">' +
            '<div class="form-group"><label>Name</label><input class="form-control" id="new-name"></div>' +
            '<div class="form-group"><label>Shift Type</label><select class="form-control" id="new-shift">' +
            SHIFT_TYPES.map(function (s) { return '<option>' + s + '</option>'; }).join('') +
            '</select></div>' +
            '<div class="form-group"><label>Custom Start</label><input class="form-control" id="new-start" placeholder="HH:MM (optional)"></div>' +
            '</div>' +
            '<div style="display:flex;gap:.5rem;margin-top:.5rem">' +
            '<button class="btn btn-primary" id="submit-new">Add</button>' +
            '<button class="btn" id="cancel-new">Cancel</button></div>';

        document.getElementById('submit-new').addEventListener('click', function () {
            var data = {
                name: document.getElementById('new-name').value,
                shift_type: document.getElementById('new-shift').value,
                custom_start: document.getElementById('new-start').value
            };
            API.addTeammate(data)
                .then(function () { Toast.show('Teammate added', 'success'); container.hidden = true; load(); })
                .catch(function (err) { Toast.show(err.message, 'error'); });
        });
        document.getElementById('cancel-new').addEventListener('click', function () {
            container.hidden = true;
        });
    }

    function load() {
        API.getTeammates()
            .then(function (list) { renderList(list || []); })
            .catch(function (err) {
                Toast.show(err.message, 'error');
                renderList([]);
            });
    }

    function exportTeamCsv() {
        API.getTeammates()
            .then(function (list) {
                var rows = ['name,shift_type,custom_start'];
                (list || []).forEach(function (t) {
                    rows.push(
                        '"' + (t.name || '').replace(/"/g, '""') + '",' +
                        (t.shift_type || '') + ',' +
                        (t.custom_start || '')
                    );
                });
                var csv = rows.join('\n');
                var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = 'teammates_export.csv';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            })
            .catch(function (err) { Toast.show(err.message, 'error'); });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('add-teammate-btn').addEventListener('click', showAddForm);
        document.getElementById('export-csv-btn').addEventListener('click', exportTeamCsv);
        var csvInput = document.getElementById('csv-file-input');
        document.getElementById('import-csv-btn').addEventListener('click', function () {
            csvInput.click();
        });
        csvInput.addEventListener('change', function () {
            if (!csvInput.files.length) return;
            API.importCsv(csvInput.files[0])
                .then(function (res) {
                    var msg = 'Imported ' + res.imported_count + ' teammates';
                    if (res.skipped_rows && res.skipped_rows.length) {
                        msg += ', skipped rows: ' + res.skipped_rows.join(', ');
                    }
                    Toast.show(msg, 'success');
                    load();
                })
                .catch(function (err) { Toast.show(err.message, 'error'); })
                .finally(function () { csvInput.value = ''; });
        });
    });

    return { load: load };
})();

function loadTeam() { Team.load(); }
