"""Override API routes for DC-ShiftMaster HTML."""

from flask import Blueprint, current_app, jsonify, request

overrides_bp = Blueprint("overrides", __name__)


@overrides_bp.route("/api/overrides/<int:year>")
def get_overrides(year: int):
    """Return all overrides for a given year as JSON array."""
    try:
        db = current_app.config["db"]
        overrides = db.get_overrides(year)
        return jsonify([
            {
                "date": o.date,
                "shift_type": o.shift_type,
                "name": o.name,
            }
            for o in overrides
        ])
    except Exception as exc:
        return jsonify({"error": f"Failed to get overrides: {exc}"}), 500


@overrides_bp.route("/api/overrides", methods=["POST"])
def set_override():
    """Set an override. Returns 201."""
    data = request.get_json(force=True)
    date_str = data.get("date", "")
    shift_type = data.get("shift_type", "")
    name = data.get("name", "")

    try:
        db = current_app.config["db"]
        db.set_override(date_str, shift_type, name)
        return jsonify({
            "date": date_str,
            "shift_type": shift_type,
            "name": name,
        }), 201
    except Exception as exc:
        return jsonify({"error": f"Failed to set override: {exc}"}), 500


@overrides_bp.route("/api/overrides", methods=["DELETE"])
def remove_override():
    """Remove an override. Returns 204."""
    data = request.get_json(force=True)
    date_str = data.get("date", "")
    shift_type = data.get("shift_type", "")

    try:
        db = current_app.config["db"]
        db.remove_override(date_str, shift_type)
        return "", 204
    except Exception as exc:
        return jsonify({"error": f"Failed to remove override: {exc}"}), 500
