"""Teammate API routes for DC-ShiftMaster HTML."""

import csv
import io

from flask import Blueprint, current_app, jsonify, request

from dc_shiftmaster.validation import validate_time_format

teammates_bp = Blueprint("teammates", __name__)

VALID_SHIFT_TYPES = {"FHD", "FHN", "BHD", "BHN"}


@teammates_bp.route("/api/teammates", methods=["GET"])
def get_teammates():
    """Return all teammates as JSON array."""
    try:
        db = current_app.config["db"]
        teammates = db.get_teammates()
        return jsonify([
            {
                "id": t.id,
                "name": t.name,
                "shift_type": t.shift_type,
                "custom_start": t.custom_start,
            }
            for t in teammates
        ])
    except Exception as exc:
        return jsonify({"error": f"Failed to get teammates: {exc}"}), 500


@teammates_bp.route("/api/teammates", methods=["POST"])
def add_teammate():
    """Add a new teammate. Returns 201 on success, 400 on validation error."""
    try:
        data = request.get_json(force=True)
        name = data.get("name", "")
        shift_type = data.get("shift_type", "FHD")
        custom_start = data.get("custom_start", "")

        if not name or not name.strip():
            return jsonify({"error": "Teammate name must not be empty."}), 400

        if shift_type not in VALID_SHIFT_TYPES:
            return jsonify({"error": f"Invalid shift type '{shift_type}'. Must be one of: FHD, FHN, BHD, BHN."}), 400

        if custom_start:
            valid, err = validate_time_format(custom_start)
            if not valid:
                return jsonify({"error": err}), 400

        db = current_app.config["db"]
        new_id = db.add_teammate(name.strip(), shift_type, custom_start)
        return jsonify({
            "id": new_id,
            "name": name.strip(),
            "shift_type": shift_type,
            "custom_start": custom_start,
        }), 201
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


@teammates_bp.route("/api/teammates/<int:tid>", methods=["PUT"])
def update_teammate(tid: int):
    """Update an existing teammate. Returns 400 on validation error."""
    try:
        data = request.get_json(force=True)
        name = data.get("name", "")
        shift_type = data.get("shift_type", "FHD")
        custom_start = data.get("custom_start", "")

        if not name or not name.strip():
            return jsonify({"error": "Teammate name must not be empty."}), 400

        if custom_start:
            valid, err = validate_time_format(custom_start)
            if not valid:
                return jsonify({"error": err}), 400

        db = current_app.config["db"]
        db.update_teammate(tid, name.strip(), shift_type, custom_start)
        return jsonify({
            "id": tid,
            "name": name.strip(),
            "shift_type": shift_type,
            "custom_start": custom_start,
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


@teammates_bp.route("/api/teammates/<int:tid>", methods=["DELETE"])
def delete_teammate(tid: int):
    """Delete a teammate. Returns 204."""
    try:
        db = current_app.config["db"]
        db.delete_teammate(tid)
        return "", 204
    except Exception as exc:
        return jsonify({"error": f"Failed to delete teammate: {exc}"}), 500


@teammates_bp.route("/api/teammates/import-csv", methods=["POST"])
def import_csv():
    """Import teammates from a CSV file upload.

    Each row: name,shift_type[,custom_start]
    Skips rows with invalid shift types.
    Returns JSON summary with imported_count and skipped_rows.
    """
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded."}), 400

    try:
        file = request.files["file"]
        content = file.read().decode("utf-8", errors="replace")
        reader = csv.reader(io.StringIO(content))

        db = current_app.config["db"]
        imported_count = 0
        skipped_rows = []

        for row_num, row in enumerate(reader, start=1):
            if not row or not row[0].strip():
                skipped_rows.append(row_num)
                continue

            name = row[0].strip()
            shift_type = row[1].strip().upper() if len(row) > 1 else ""
            custom_start = row[2].strip() if len(row) > 2 else ""

            if shift_type not in VALID_SHIFT_TYPES:
                skipped_rows.append(row_num)
                continue

            db.add_teammate(name, shift_type, custom_start)
            imported_count += 1

        return jsonify({
            "imported_count": imported_count,
            "skipped_rows": skipped_rows,
        })
    except Exception as exc:
        return jsonify({"error": f"CSV import failed: {exc}"}), 500
